import './settings';
import './objects';
import './indices';
