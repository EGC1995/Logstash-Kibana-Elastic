'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _rename = require('./rename');

Object.defineProperty(exports, 'rename', {
  enumerable: true,
  get: function get() {
    return _rename.rename;
  }
});

var _unused = require('./unused');

Object.defineProperty(exports, 'unused', {
  enumerable: true,
  get: function get() {
    return _unused.unused;
  }
});
